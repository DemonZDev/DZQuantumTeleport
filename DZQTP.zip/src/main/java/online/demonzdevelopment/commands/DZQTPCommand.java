package online.demonzdevelopment.commands;

import online.demonzdevelopment.DZQuantumTeleport;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DZQTPCommand implements CommandExecutor, TabCompleter {
    private final DZQuantumTeleport plugin;
    
    public DZQTPCommand(DZQuantumTeleport plugin) { 
        this.plugin = plugin; 
    }
    
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String subCommand = args[0].toLowerCase();

        switch (subCommand) {
            case "reload":
                if (!sender.hasPermission("dzqtp.admin")) {
                    sender.sendMessage("§cYou don't have permission to use this command!");
                    return true;
                }
                plugin.getConfigManager().reload();
                plugin.getMessageManager().reload();
                plugin.getRankManager().reload();
                plugin.getCombatManager().loadConfig();
                sender.sendMessage(plugin.getMessageManager().getMessage("general.reload-success"));
                return true;

            case "update":
                if (!sender.hasPermission("dzqtp.admin") && !sender.hasPermission("dzqtp.update")) {
                    sender.sendMessage("§cYou don't have permission to use this command!");
                    return true;
                }
                handleUpdateCommand(sender, args);
                return true;

            case "credits":
                handleCreditsCommand(sender);
                return true;

            default:
                sendHelp(sender);
                return true;
        }
    }

    /**
     * Handle update command
     */
    private void handleUpdateCommand(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /dzqtp update <previous|next|latest|auto>");
            return;
        }

        String updateType = args[1].toLowerCase();
        
        switch (updateType) {
            case "previous":
                sender.sendMessage("§eChecking for previous version...");
                String previousVersion = plugin.getUpdateManager().getPreviousVersion();
                if (previousVersion == null) {
                    sender.sendMessage("§cNo previous version available!");
                    return;
                }
                sender.sendMessage("§eDownloading version " + previousVersion + "...");
                if (plugin.getUpdateManager().updateToVersion(previousVersion)) {
                    sender.sendMessage("§aSuccessfully updated to version " + previousVersion + "!");
                    sender.sendMessage("§cPlease restart the server to apply changes.");
                } else {
                    sender.sendMessage("§cFailed to download update! Check console for details.");
                }
                break;

            case "next":
                sender.sendMessage("§eChecking for next version...");
                String nextVersion = plugin.getUpdateManager().getNextVersion();
                if (nextVersion == null) {
                    sender.sendMessage("§cNo next version available!");
                    return;
                }
                sender.sendMessage("§eDownloading version " + nextVersion + "...");
                if (plugin.getUpdateManager().updateToVersion(nextVersion)) {
                    sender.sendMessage("§aSuccessfully updated to version " + nextVersion + "!");
                    sender.sendMessage("§cPlease restart the server to apply changes.");
                } else {
                    sender.sendMessage("§cFailed to download update! Check console for details.");
                }
                break;

            case "latest":
                sender.sendMessage("§eChecking for latest version...");
                plugin.getUpdateManager().checkForUpdates();
                if (!plugin.getUpdateManager().isUpdateAvailable()) {
                    sender.sendMessage("§aYou are already running the latest version!");
                    return;
                }
                String latestVersion = plugin.getUpdateManager().getLatestVersion();
                sender.sendMessage("§eDownloading version " + latestVersion + "...");
                if (plugin.getUpdateManager().updateToVersion(latestVersion)) {
                    sender.sendMessage("§aSuccessfully updated to version " + latestVersion + "!");
                    sender.sendMessage("§cPlease restart the server to apply changes.");
                } else {
                    sender.sendMessage("§cFailed to download update! Check console for details.");
                }
                break;

            case "auto":
                boolean currentState = plugin.getUpdateManager().isAutoUpdateEnabled();
                plugin.getUpdateManager().saveAutoUpdate(!currentState);
                if (!currentState) {
                    sender.sendMessage("§aAuto-update enabled! The plugin will automatically update when a new version is found.");
                    sender.sendMessage("§eNote: You will still need to restart the server to apply updates.");
                    // Check for update immediately
                    plugin.getUpdateManager().checkForUpdates();
                    if (plugin.getUpdateManager().isUpdateAvailable()) {
                        sender.sendMessage("§eUpdate available! Downloading...");
                        if (plugin.getUpdateManager().updateToVersion(plugin.getUpdateManager().getLatestVersion())) {
                            sender.sendMessage("§aSuccessfully downloaded! Restart server to apply.");
                        }
                    }
                } else {
                    sender.sendMessage("§cAuto-update disabled!");
                }
                break;

            default:
                sender.sendMessage("§eUsage: /dzqtp update <previous|next|latest|auto>");
                break;
        }
    }

    /**
     * Handle credits command
     */
    private void handleCreditsCommand(CommandSender sender) {
        sender.sendMessage("§8§m                                            ");
        sender.sendMessage("§a§lDZQuantumTeleport §7is created by §e§lDemonZ Development");
        sender.sendMessage("");
        sender.sendMessage("§e§lDemonZ Development Ecosystem");
        sender.sendMessage("§7-- §bhttps://demonzdevelopment.online");
        sender.sendMessage("§7-- §bhttps://hyzerox.me");
        sender.sendMessage("§8§m                                            ");
    }

    /**
     * Send help message
     */
    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§8§m                                            ");
        sender.sendMessage("§a§lDZQuantumTeleport Commands");
        sender.sendMessage("");
        sender.sendMessage("§e/dzqtp reload §7- Reload configuration");
        sender.sendMessage("§e/dzqtp update <previous|next|latest|auto> §7- Manage updates");
        sender.sendMessage("§e/dzqtp credits §7- Show plugin credits");
        sender.sendMessage("§8§m                                            ");
    }

    @Nullable
    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.addAll(Arrays.asList("reload", "update", "credits"));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("update")) {
            completions.addAll(Arrays.asList("previous", "next", "latest", "auto"));
        }

        return completions;
    }
}

