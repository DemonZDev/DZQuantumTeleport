package online.demonzdevelopment.listeners;

import online.demonzdevelopment.DZQuantumTeleport;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * Player Damage Listener
 * Cancels warmup if player takes damage and handles combat tagging
 */
public class PlayerDamageListener implements Listener {

    private final DZQuantumTeleport plugin;

    public PlayerDamageListener(DZQuantumTeleport plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDamage(EntityDamageEvent event) {
        // TODO: Implement warmup cancellation logic
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // PvP Combat Tagging
        if (event.getEntity() instanceof Player && event.getDamager() instanceof Player) {
            Player victim = (Player) event.getEntity();
            Player attacker = (Player) event.getDamager();
            
            // Tag both players for PvP
            plugin.getCombatManager().tagPvP(victim);
            plugin.getCombatManager().tagPvP(attacker);
        }
        
        // PvE Combat Tagging
        if (event.getEntity() instanceof Player && event.getDamager() instanceof LivingEntity) {
            Player player = (Player) event.getEntity();
            Entity damager = event.getDamager();
            
            // Tag player for PvE if damaged by dangerous mob
            plugin.getCombatManager().tagPvE(player, damager.getType());
        }
        
        // Player attacking mob - also tag for PvE
        if (event.getDamager() instanceof Player && event.getEntity() instanceof LivingEntity) {
            Player player = (Player) event.getDamager();
            Entity entity = event.getEntity();
            
            // Tag player for PvE if attacking dangerous mob
            plugin.getCombatManager().tagPvE(player, entity.getType());
        }
    }
}
