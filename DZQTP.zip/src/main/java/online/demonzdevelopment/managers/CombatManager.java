package online.demonzdevelopment.managers;

import online.demonzdevelopment.DZQuantumTeleport;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Combat Manager
 * Handles PvP and PvE combat tagging to prevent GUI popups during combat
 */
public class CombatManager {

    private final DZQuantumTeleport plugin;
    private final Map<UUID, Long> pvpCombatTags = new ConcurrentHashMap<>();
    private final Map<UUID, Long> pveCombatTags = new ConcurrentHashMap<>();
    
    private boolean pvpProtectionEnabled;
    private int pvpCombatDuration;
    private boolean pveProtectionEnabled;
    private int pveCombatDuration;
    private Set<EntityType> dangerousMobs;

    public CombatManager(DZQuantumTeleport plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    /**
     * Load configuration
     */
    public void loadConfig() {
        // PvP settings
        pvpProtectionEnabled = plugin.getConfig().getBoolean("combat-protection.pvp.enabled", true);
        pvpCombatDuration = plugin.getConfig().getInt("combat-protection.pvp.duration-seconds", 30);
        
        // PvE settings
        pveProtectionEnabled = plugin.getConfig().getBoolean("combat-protection.pve.enabled", true);
        pveCombatDuration = plugin.getConfig().getInt("combat-protection.pve.duration-seconds", 30);
        
        // Load dangerous mobs
        dangerousMobs = new HashSet<>();
        List<String> mobList = plugin.getConfig().getStringList("combat-protection.pve.dangerous-mobs");
        
        if (mobList.isEmpty()) {
            // Default dangerous mobs
            mobList = Arrays.asList(
                "ENDER_DRAGON",
                "WITHER",
                "WARDEN",
                "CREEPER",
                "SKELETON",
                "STRAY",
                "ZOMBIE",
                "HUSK",
                "DROWNED",
                "SPIDER",
                "CAVE_SPIDER",
                "ENDERMAN",
                "BLAZE",
                "GHAST",
                "PHANTOM",
                "VEX",
                "VINDICATOR",
                "EVOKER",
                "PILLAGER",
                "RAVAGER",
                "PIGLIN_BRUTE",
                "HOGLIN",
                "ZOGLIN",
                "WITCH"
            );
        }
        
        for (String mobName : mobList) {
            try {
                dangerousMobs.add(EntityType.valueOf(mobName.toUpperCase()));
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Invalid mob type in config: " + mobName);
            }
        }
    }

    /**
     * Tag player for PvP combat
     */
    public void tagPvP(Player player) {
        if (!pvpProtectionEnabled) return;
        
        pvpCombatTags.put(player.getUniqueId(), System.currentTimeMillis() + (pvpCombatDuration * 1000L));
    }

    /**
     * Tag player for PvE combat
     */
    public void tagPvE(Player player, EntityType mobType) {
        if (!pveProtectionEnabled) return;
        if (!isDangerousMob(mobType)) return;
        
        pveCombatTags.put(player.getUniqueId(), System.currentTimeMillis() + (pveCombatDuration * 1000L));
    }

    /**
     * Check if entity is dangerous mob
     */
    public boolean isDangerousMob(EntityType type) {
        return dangerousMobs.contains(type);
    }

    /**
     * Check if player is in PvP combat
     */
    public boolean isInPvP(Player player) {
        if (!pvpProtectionEnabled) return false;
        
        Long expireTime = pvpCombatTags.get(player.getUniqueId());
        if (expireTime == null) return false;
        
        if (System.currentTimeMillis() > expireTime) {
            pvpCombatTags.remove(player.getUniqueId());
            return false;
        }
        
        return true;
    }

    /**
     * Check if player is in PvE combat
     */
    public boolean isInPvE(Player player) {
        if (!pveProtectionEnabled) return false;
        
        Long expireTime = pveCombatTags.get(player.getUniqueId());
        if (expireTime == null) return false;
        
        if (System.currentTimeMillis() > expireTime) {
            pveCombatTags.remove(player.getUniqueId());
            return false;
        }
        
        return true;
    }

    /**
     * Check if player is in any combat
     */
    public boolean isInCombat(Player player) {
        return isInPvP(player) || isInPvE(player);
    }

    /**
     * Get remaining combat time in seconds
     */
    public int getRemainingCombatTime(Player player) {
        long pvpTime = pvpCombatTags.getOrDefault(player.getUniqueId(), 0L);
        long pveTime = pveCombatTags.getOrDefault(player.getUniqueId(), 0L);
        long maxTime = Math.max(pvpTime, pveTime);
        
        if (maxTime == 0) return 0;
        
        long remaining = maxTime - System.currentTimeMillis();
        return remaining > 0 ? (int) (remaining / 1000) : 0;
    }

    /**
     * Get combat type message
     */
    public String getCombatTypeMessage(Player player) {
        if (isInPvP(player) && isInPvE(player)) {
            return "You are in combat! GUI is disabled. (" + getRemainingCombatTime(player) + "s remaining)";
        } else if (isInPvP(player)) {
            return "You are in PvP combat! GUI is disabled. (" + getRemainingCombatTime(player) + "s remaining)";
        } else if (isInPvE(player)) {
            return "You are in PvE combat! GUI is disabled. (" + getRemainingCombatTime(player) + "s remaining)";
        }
        return "";
    }

    /**
     * Clear combat tag
     */
    public void clearCombatTag(Player player) {
        pvpCombatTags.remove(player.getUniqueId());
        pveCombatTags.remove(player.getUniqueId());
    }

    /**
     * Clear all combat tags
     */
    public void clearAllTags() {
        pvpCombatTags.clear();
        pveCombatTags.clear();
    }

    /**
     * Remove player from combat tracking on quit
     */
    public void removePlayer(UUID uuid) {
        pvpCombatTags.remove(uuid);
        pveCombatTags.remove(uuid);
    }
}
