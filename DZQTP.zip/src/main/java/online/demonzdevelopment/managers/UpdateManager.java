package online.demonzdevelopment.managers;

import online.demonzdevelopment.DZQuantumTeleport;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.logging.Level;

/**
 * Update Manager
 * Handles plugin updates from GitHub releases
 */
public class UpdateManager {

    private final DZQuantumTeleport plugin;
    private final String GITHUB_API_URL = "https://api.github.com/repos/DemonZDev/DZQuantumTeleport/releases";
    private final String currentVersion;
    private String latestVersion = null;
    private List<String> availableVersions = new ArrayList<>();
    private boolean autoUpdateEnabled = false;
    private boolean updateCheckEnabled = true;
    private int checkIntervalMinutes = 60; // Default 60 minutes
    private boolean updateAvailable = false;
    private String downloadUrl = null;

    public UpdateManager(DZQuantumTeleport plugin) {
        this.plugin = plugin;
        this.currentVersion = plugin.getDescription().getVersion();
        
        // Load config
        loadConfig();
        
        // Start update checker if enabled
        if (updateCheckEnabled) {
            startUpdateChecker();
        }
    }

    /**
     * Load configuration
     */
    private void loadConfig() {
        autoUpdateEnabled = plugin.getConfig().getBoolean("update.auto-update", false);
        updateCheckEnabled = plugin.getConfig().getBoolean("update.check-enabled", true);
        checkIntervalMinutes = plugin.getConfig().getInt("update.check-interval-minutes", 60);
    }

    /**
     * Save auto-update configuration
     */
    public void saveAutoUpdate(boolean enabled) {
        plugin.getConfig().set("update.auto-update", enabled);
        plugin.saveConfig();
        this.autoUpdateEnabled = enabled;
    }

    /**
     * Start update checker task
     */
    private void startUpdateChecker() {
        new BukkitRunnable() {
            @Override
            public void run() {
                checkForUpdates();
                
                if (updateAvailable) {
                    if (autoUpdateEnabled) {
                        // Auto update
                        plugin.getLogger().info("New update found! Auto-updating...");
                        downloadUpdate();
                        notifyAdmins("§a[DZQuantumTeleport] §ePlugin updated to version " + latestVersion + "! §cPlease restart the server.");
                    } else {
                        // Notify admins
                        notifyAdmins("§a[DZQuantumTeleport] §eNew update available: " + latestVersion + "! Use /dzqtp update latest to update.");
                    }
                }
            }
        }.runTaskTimerAsynchronously(plugin, 200L, checkIntervalMinutes * 60L * 20L); // Check after 10 seconds, then every X minutes
    }

    /**
     * Check for updates from GitHub
     */
    public boolean checkForUpdates() {
        try {
            URL url = new URL(GITHUB_API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("User-Agent", "DZQuantumTeleport");

            int responseCode = connection.getResponseCode();
            if (responseCode == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Parse JSON
                JSONParser parser = new JSONParser();
                JSONArray releases = (JSONArray) parser.parse(response.toString());
                
                availableVersions.clear();
                
                for (Object obj : releases) {
                    JSONObject release = (JSONObject) obj;
                    String version = ((String) release.get("tag_name")).replace("v", "");
                    availableVersions.add(version);
                    
                    // Get latest version
                    if (latestVersion == null) {
                        latestVersion = version;
                        JSONArray assets = (JSONArray) release.get("assets");
                        if (assets != null && !assets.isEmpty()) {
                            JSONObject asset = (JSONObject) assets.get(0);
                            downloadUrl = (String) asset.get("browser_download_url");
                        }
                    }
                }

                // Check if update available
                if (latestVersion != null && !currentVersion.equals(latestVersion)) {
                    updateAvailable = true;
                    return true;
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to check for updates: " + e.getMessage());
        }
        return false;
    }

    /**
     * Update to specific version
     */
    public boolean updateToVersion(String version) {
        try {
            // Find version in releases
            URL url = new URL(GITHUB_API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("User-Agent", "DZQuantumTeleport");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            JSONParser parser = new JSONParser();
            JSONArray releases = (JSONArray) parser.parse(response.toString());
            
            for (Object obj : releases) {
                JSONObject release = (JSONObject) obj;
                String releaseVersion = ((String) release.get("tag_name")).replace("v", "");
                
                if (releaseVersion.equals(version)) {
                    JSONArray assets = (JSONArray) release.get("assets");
                    if (assets != null && !assets.isEmpty()) {
                        JSONObject asset = (JSONObject) assets.get(0);
                        String downloadUrl = (String) asset.get("browser_download_url");
                        return downloadFile(downloadUrl);
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to update to version " + version + ": " + e.getMessage());
        }
        return false;
    }

    /**
     * Download latest update
     */
    private boolean downloadUpdate() {
        if (downloadUrl == null) {
            checkForUpdates();
        }
        
        if (downloadUrl == null) {
            plugin.getLogger().severe("No download URL found!");
            return false;
        }
        
        return downloadFile(downloadUrl);
    }

    /**
     * Download file from URL
     */
    private boolean downloadFile(String fileUrl) {
        try {
            URL url = new URL(fileUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("User-Agent", "DZQuantumTeleport");

            // Get plugin file path
            File pluginFile = new File(plugin.getClass().getProtectionDomain().getCodeSource().getLocation().toURI());
            File updateFolder = new File(pluginFile.getParentFile(), "update");
            if (!updateFolder.exists()) {
                updateFolder.mkdirs();
            }
            
            File outputFile = new File(updateFolder, pluginFile.getName());

            // Download
            try (InputStream in = connection.getInputStream();
                 FileOutputStream out = new FileOutputStream(outputFile)) {
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
            }

            plugin.getLogger().info("Update downloaded successfully! File will be loaded on next restart.");
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to download update: " + e.getMessage(), e);
            return false;
        }
    }

    /**
     * Get previous version
     */
    public String getPreviousVersion() {
        if (availableVersions.isEmpty()) {
            checkForUpdates();
        }
        
        int currentIndex = availableVersions.indexOf(currentVersion);
        if (currentIndex > 0 && currentIndex < availableVersions.size()) {
            return availableVersions.get(currentIndex + 1);
        }
        return null;
    }

    /**
     * Get next version
     */
    public String getNextVersion() {
        if (availableVersions.isEmpty()) {
            checkForUpdates();
        }
        
        int currentIndex = availableVersions.indexOf(currentVersion);
        if (currentIndex > 0) {
            return availableVersions.get(currentIndex - 1);
        }
        return null;
    }

    /**
     * Notify all online admins
     */
    private void notifyAdmins(String message) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.hasPermission("dzqtp.admin") || player.hasPermission("dzqtp.update.notify")) {
                player.sendMessage(message);
            }
        }
    }

    /**
     * Notify admin on join
     */
    public void notifyAdminOnJoin(Player player) {
        if (updateAvailable && (player.hasPermission("dzqtp.admin") || player.hasPermission("dzqtp.update.notify"))) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    player.sendMessage("§a[DZQuantumTeleport] §eNew update available: " + latestVersion + "!");
                    if (!autoUpdateEnabled) {
                        player.sendMessage("§7Use /dzqtp update latest to update.");
                    } else {
                        player.sendMessage("§7Auto-update is enabled. Restart server to apply.");
                    }
                }
            }.runTaskLater(plugin, 40L);
        }
    }

    public String getCurrentVersion() {
        return currentVersion;
    }

    public String getLatestVersion() {
        return latestVersion;
    }

    public boolean isUpdateAvailable() {
        return updateAvailable;
    }

    public boolean isAutoUpdateEnabled() {
        return autoUpdateEnabled;
    }
}
