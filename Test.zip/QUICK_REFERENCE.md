# DZEconomy 1.1.1 Integration - Quick Reference

## What Changed?

### API Interface - NEW Methods
```java
// Transfer currency between players
boolean transferCurrency(UUID from, UUID to, CurrencyType type, double amount);

// Convert between currency types
boolean convertCurrency(UUID uuid, CurrencyType fromType, CurrencyType toType, double amount);

// Get player rank with settings
Rank getPlayerRank(UUID uuid);
```

### EconomyManager - NEW Methods
```java
// Get formatted balance
String getFormattedBalance(Player player, CurrencyType type);

// Get all balances formatted
Map<CurrencyType, String> getAllFormattedBalances(Player player);

// Execute transaction with result
TransactionResult attemptTransaction(Player player, Cost cost);

// Check if API is available
boolean isAvailable();

// Get direct API access
DZEconomyAPI getAPI();
```

### EconomyManager - IMPROVED Methods
```java
// Now returns formatted amounts (e.g., "$1.5K" not "$1500")
List<String> getMissingAmounts(Player player, Cost cost);

// Now uses DZEconomy's formatter for K/M/B notation
String formatCost(Cost cost);
```

## Quick Code Examples

### Display Formatted Cost
```java
Cost cost = plugin.getEconomyManager().getCost(player, "home");
String formatted = plugin.getEconomyManager().formatCost(cost);
player.sendMessage("Cost: " + formatted);
```

### Show Missing Amounts (Formatted)
```java
if (!plugin.getEconomyManager().canAfford(player, cost)) {
    for (String missing : plugin.getEconomyManager().getMissingAmounts(player, cost)) {
        player.sendMessage("  - " + missing);
    }
}
```

### Transaction with Detailed Result
```java
TransactionResult result = plugin.getEconomyManager().attemptTransaction(player, cost);
if (result.isSuccess()) {
    // Proceed
} else {
    player.sendMessage(result.getMessage());
    for (String detail : result.getDetails()) {
        player.sendMessage("  - " + detail);
    }
}
```

### Display Player Balance
```java
String balance = plugin.getEconomyManager().getFormattedBalance(player, CurrencyType.MONEY);
player.sendMessage("Balance: " + balance);
```

## Currency Formatting Examples

| Raw Amount | Formatted |
|------------|-----------|
| 500 | $500 |
| 1,000 | $1K |
| 1,500 | $1.5K |
| 50,000 | $50K |
| 1,000,000 | $1M |
| 2,500,000 | $2.5M |
| 1,000,000,000 | $1B |

## Error Messages - Before vs After

### Before (Old)
```
Insufficient funds! Missing:
  - Money: $1500
  - MobCoins: 250 MC
  - Gems: 50 ◆
```

### After (New)
```
Insufficient funds! Missing:
  - Money: $1.5K
  - MobCoins: 250 MC
  - Gems: 50 ◆
```

## Files Changed

1. `DZEconomyAPI.java` - Interface updated with 1.1.1 methods
2. `EconomyManager.java` - Enhanced with utilities and formatting
3. `DZQuantumTeleport.java` - Better error handling

## Backward Compatibility

✅ All existing code works without changes
✅ Enhanced formatting automatically applies
✅ No breaking changes

## Testing

**Check console for:**
```
Successfully hooked into DZEconomy 1.1.1!
DZEconomy API verified and ready!
```

**Test commands:**
- `/sethome test` - Should show formatted cost
- Try without funds - Should show formatted missing amounts

## Dependencies

**Required:**
- DZEconomy 1.1.1+
- LuckPerms 5.4+
- PaperMC 1.21.1

## Support

If you see:
```
DZEconomy not found!
```
→ Install DZEconomy 1.1.1+

If you see:
```
Failed to retrieve DZEconomy API!
```
→ Verify DZEconomy version is 1.1.1+

---

**Status**: ✅ Complete and Production Ready
**Version**: DZQuantumTeleport 1.0.0 with DZEconomy 1.1.1 support
