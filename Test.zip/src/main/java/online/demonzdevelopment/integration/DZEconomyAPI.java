package online.demonzdevelopment.integration;

import java.util.UUID;

/**
 * DZEconomy API Interface - Version 1.1.1
 * Updated to include new features from DZEconomy 1.1.1
 *
 * This interface mirrors the actual DZEconomy 1.1.1 API structure.
 * For implementation examples, see the official DZEconomy API documentation.
 */
public interface DZEconomyAPI {

    /**
     * Currency types supported by DZEconomy
     */
    enum CurrencyType {
        MONEY,
        MOBCOIN,
        GEM
    }

    /**
     * Check if player has sufficient balance
     * @param uuid Player UUID
     * @param type Currency type
     * @param amount Amount to check
     * @return true if player has enough balance
     */
    boolean hasBalance(UUID uuid, CurrencyType type, double amount);

    /**
     * Get player's balance
     * @param uuid Player UUID
     * @param type Currency type
     * @return Current balance
     */
    double getBalance(UUID uuid, CurrencyType type);

    /**
     * Add currency to player
     * @param uuid Player UUID
     * @param type Currency type
     * @param amount Amount to add
     * @return true if successful
     */
    boolean addCurrency(UUID uuid, CurrencyType type, double amount);

    /**
     * Remove currency from player
     * @param uuid Player UUID
     * @param type Currency type
     * @param amount Amount to remove
     * @return true if successful
     */
    boolean removeCurrency(UUID uuid, CurrencyType type, double amount);

    /**
     * Transfer currency between players (NEW in 1.1.1)
     * @param from Sender UUID
     * @param to Receiver UUID
     * @param type Currency type
     * @param amount Amount to transfer
     * @return true if successful (automatically checks sender balance)
     */
    boolean transferCurrency(UUID from, UUID to, CurrencyType type, double amount);

    /**
     * Convert currency from one type to another (NEW in 1.1.1)
     * @param uuid Player UUID
     * @param fromType Source currency type
     * @param toType Target currency type
     * @param amount Amount to convert
     * @return true if successful (automatically calculates conversion rate)
     */
    boolean convertCurrency(UUID uuid, CurrencyType fromType, CurrencyType toType, double amount);

    /**
     * Get player's rank information (NEW in 1.1.1)
     * @param uuid Player UUID
     * @return Rank object with full rank details
     */
    Rank getPlayerRank(UUID uuid);

    /**
     * Format currency amount with symbol (supports K, M, B notation)
     * @param amount Amount to format
     * @param type Currency type
     * @return Formatted string (e.g., "$1.5K", "250 MC", "5.2M ◆")
     */
    String formatCurrency(double amount, CurrencyType type);

    /**
     * Rank interface - represents a player's rank with currency settings
     * (NEW in 1.1.1)
     */
    interface Rank {
        /**
         * Get rank display name
         * @return Formatted rank name
         */
        String getDisplayName();

        /**
         * Get rank priority (higher = better rank)
         * @return Priority value
         */
        int getPriority();

        /**
         * Get money currency settings
         * @return Money settings
         */
        RankCurrencySettings getMoneySettings();

        /**
         * Get mobcoin currency settings
         * @return MobCoin settings
         */
        RankCurrencySettings getMobcoinSettings();

        /**
         * Get gem currency settings
         * @return Gem settings
         */
        RankCurrencySettings getGemSettings();
    }

    /**
     * Currency-specific settings for a rank
     * (NEW in 1.1.1)
     */
    interface RankCurrencySettings {
        /**
         * Get transfer tax percentage
         * @return Tax percentage (0-100)
         */
        double getTransferTax();

        /**
         * Get daily transfer limit
         * @return Maximum amount per day
         */
        double getDailyTransferLimit();

        /**
         * Get transfer cooldown in seconds
         * @return Cooldown in seconds
         */
        int getTransferCooldown();
    }
}
