package online.demonzdevelopment.managers;

import online.demonzdevelopment.DZQuantumTeleport;
import online.demonzdevelopment.config.RankManager;
import online.demonzdevelopment.integration.DZEconomyAPI;
import online.demonzdevelopment.models.Cost;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * Economy Manager
 * Handles all cost calculations and transactions
 */
public class EconomyManager {

    private final DZQuantumTeleport plugin;
    private final DZEconomyAPI economyAPI;

    public EconomyManager(DZQuantumTeleport plugin, DZEconomyAPI economyAPI) {
        this.plugin = plugin;
        this.economyAPI = economyAPI;
    }

    /**
     * Get cost for a command based on player's rank
     * @param player Player
     * @param command Command name
     * @return Cost object
     */
    public Cost getCost(Player player, String command) {
        String rank = plugin.getRankManager().getPlayerRank(player);
        
        // Check if rank bypasses costs
        if (plugin.getRankManager().bypassesAllCosts(rank)) {
            return new Cost();
        }

        // Check bypass permission
        if (player.hasPermission("dzqtp.bypass.cost")) {
            return new Cost();
        }

        ConfigurationSection config = plugin.getRankManager().getCommandConfig(rank, command);
        if (config == null) {
            return new Cost();
        }

        ConfigurationSection costsSection = config.getConfigurationSection("costs");
        if (costsSection == null) {
            return new Cost();
        }

        Cost cost = new Cost();
        cost.setMoney(costsSection.getDouble("money", 0));
        cost.setMobcoin(costsSection.getDouble("mobcoin", 0));
        cost.setGem(costsSection.getDouble("gem", 0));
        cost.setXpLevels(costsSection.getInt("xp-levels", 0));

        // Load items
        if (costsSection.contains("items")) {
            List<?> itemsList = costsSection.getList("items");
            if (itemsList != null) {
                for (Object obj : itemsList) {
                    if (obj instanceof Map) {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> itemMap = (Map<String, Object>) obj;
                        String material = (String) itemMap.get("material");
                        int amount = ((Number) itemMap.get("amount")).intValue();
                        cost.addItem(new Cost.ItemCost(material, amount));
                    }
                }
            }
        }

        return cost;
    }

    /**
     * Check if player can afford a cost
     * @param player Player
     * @param cost Cost to check
     * @return true if player can afford
     */
    public boolean canAfford(Player player, Cost cost) {
        // Check money
        if (cost.getMoney() > 0) {
            if (!economyAPI.hasBalance(player.getUniqueId(), DZEconomyAPI.CurrencyType.MONEY, cost.getMoney())) {
                return false;
            }
        }

        // Check mobcoin
        if (cost.getMobcoin() > 0) {
            if (!economyAPI.hasBalance(player.getUniqueId(), DZEconomyAPI.CurrencyType.MOBCOIN, cost.getMobcoin())) {
                return false;
            }
        }

        // Check gem
        if (cost.getGem() > 0) {
            if (!economyAPI.hasBalance(player.getUniqueId(), DZEconomyAPI.CurrencyType.GEM, cost.getGem())) {
                return false;
            }
        }

        // Check XP
        if (cost.getXpLevels() > 0) {
            if (player.getLevel() < cost.getXpLevels()) {
                return false;
            }
        }

        // Check items
        for (Cost.ItemCost itemCost : cost.getItems()) {
            Material material = Material.getMaterial(itemCost.getMaterial());
            if (material == null) continue;
            
            ItemStack item = new ItemStack(material, itemCost.getAmount());
            if (!player.getInventory().containsAtLeast(item, itemCost.getAmount())) {
                return false;
            }
        }

        return true;
    }

    /**
     * Charge player the cost
     * @param player Player
     * @param cost Cost to charge
     * @return true if successful
     */
    public boolean chargeCost(Player player, Cost cost) {
        if (!canAfford(player, cost)) {
            return false;
        }

        // Remove money
        if (cost.getMoney() > 0) {
            economyAPI.removeCurrency(player.getUniqueId(), DZEconomyAPI.CurrencyType.MONEY, cost.getMoney());
        }

        // Remove mobcoin
        if (cost.getMobcoin() > 0) {
            economyAPI.removeCurrency(player.getUniqueId(), DZEconomyAPI.CurrencyType.MOBCOIN, cost.getMobcoin());
        }

        // Remove gem
        if (cost.getGem() > 0) {
            economyAPI.removeCurrency(player.getUniqueId(), DZEconomyAPI.CurrencyType.GEM, cost.getGem());
        }

        // Remove XP
        if (cost.getXpLevels() > 0) {
            player.setLevel(player.getLevel() - cost.getXpLevels());
        }

        // Remove items
        for (Cost.ItemCost itemCost : cost.getItems()) {
            Material material = Material.getMaterial(itemCost.getMaterial());
            if (material == null) continue;
            
            ItemStack item = new ItemStack(material, itemCost.getAmount());
            player.getInventory().removeItem(item);
        }

        return true;
    }

    /**
     * Refund cost to player
     * @param player Player
     * @param cost Cost to refund
     * @param percentage Refund percentage (0.0 - 1.0)
     */
    public void refundCost(Player player, Cost cost, double percentage) {
        // Refund money
        if (cost.getMoney() > 0) {
            double refund = cost.getMoney() * percentage;
            economyAPI.addCurrency(player.getUniqueId(), DZEconomyAPI.CurrencyType.MONEY, refund);
        }

        // Refund mobcoin
        if (cost.getMobcoin() > 0) {
            double refund = cost.getMobcoin() * percentage;
            economyAPI.addCurrency(player.getUniqueId(), DZEconomyAPI.CurrencyType.MOBCOIN, refund);
        }

        // Refund gem
        if (cost.getGem() > 0) {
            double refund = cost.getGem() * percentage;
            economyAPI.addCurrency(player.getUniqueId(), DZEconomyAPI.CurrencyType.GEM, refund);
        }

        // Refund XP
        if (cost.getXpLevels() > 0) {
            int refund = (int) (cost.getXpLevels() * percentage);
            player.setLevel(player.getLevel() + refund);
        }

        // Refund items
        for (Cost.ItemCost itemCost : cost.getItems()) {
            Material material = Material.getMaterial(itemCost.getMaterial());
            if (material == null) continue;
            
            int refund = (int) (itemCost.getAmount() * percentage);
            ItemStack item = new ItemStack(material, refund);
            player.getInventory().addItem(item);
        }
    }

    /**
     * Get missing amounts message with formatted currency
     * @param player Player
     * @param cost Cost
     * @return List of missing items
     */
    public List<String> getMissingAmounts(Player player, Cost cost) {
        List<String> missing = new ArrayList<>();

        // Check money
        if (cost.getMoney() > 0) {
            double current = economyAPI.getBalance(player.getUniqueId(), DZEconomyAPI.CurrencyType.MONEY);
            if (current < cost.getMoney()) {
                double needed = cost.getMoney() - current;
                String formatted = economyAPI.formatCurrency(needed, DZEconomyAPI.CurrencyType.MONEY);
                missing.add("Money: " + formatted);
            }
        }

        // Check mobcoin
        if (cost.getMobcoin() > 0) {
            double current = economyAPI.getBalance(player.getUniqueId(), DZEconomyAPI.CurrencyType.MOBCOIN);
            if (current < cost.getMobcoin()) {
                double needed = cost.getMobcoin() - current;
                String formatted = economyAPI.formatCurrency(needed, DZEconomyAPI.CurrencyType.MOBCOIN);
                missing.add("MobCoins: " + formatted);
            }
        }

        // Check gem
        if (cost.getGem() > 0) {
            double current = economyAPI.getBalance(player.getUniqueId(), DZEconomyAPI.CurrencyType.GEM);
            if (current < cost.getGem()) {
                double needed = cost.getGem() - current;
                String formatted = economyAPI.formatCurrency(needed, DZEconomyAPI.CurrencyType.GEM);
                missing.add("Gems: " + formatted);
            }
        }

        // Check XP
        if (cost.getXpLevels() > 0 && player.getLevel() < cost.getXpLevels()) {
            missing.add("XP Levels: " + (cost.getXpLevels() - player.getLevel()));
        }

        // Check items
        for (Cost.ItemCost itemCost : cost.getItems()) {
            Material material = Material.getMaterial(itemCost.getMaterial());
            if (material == null) continue;

            ItemStack item = new ItemStack(material, itemCost.getAmount());
            if (!player.getInventory().containsAtLeast(item, itemCost.getAmount())) {
                int has = 0;
                for (ItemStack invItem : player.getInventory().getContents()) {
                    if (invItem != null && invItem.getType() == material) {
                        has += invItem.getAmount();
                    }
                }
                missing.add(itemCost.getMaterial() + ": " + (itemCost.getAmount() - has));
            }
        }

        return missing;
    }

    /**
     * Format cost as string using DZEconomy's formatCurrency
     * @param cost Cost
     * @return Formatted string with proper currency symbols and K/M/B notation
     */
    public String formatCost(Cost cost) {
        if (!cost.hasCost()) {
            return "Free";
        }

        List<String> parts = new ArrayList<>();

        if (cost.getMoney() > 0) {
            parts.add(economyAPI.formatCurrency(cost.getMoney(), DZEconomyAPI.CurrencyType.MONEY));
        }
        if (cost.getMobcoin() > 0) {
            parts.add(economyAPI.formatCurrency(cost.getMobcoin(), DZEconomyAPI.CurrencyType.MOBCOIN));
        }
        if (cost.getGem() > 0) {
            parts.add(economyAPI.formatCurrency(cost.getGem(), DZEconomyAPI.CurrencyType.GEM));
        }
        if (cost.getXpLevels() > 0) {
            parts.add(cost.getXpLevels() + " XP Levels");
        }
        for (Cost.ItemCost item : cost.getItems()) {
            parts.add(item.getAmount() + "x " + item.getMaterial());
        }

        return String.join(", ", parts);
    }

    /**
     * Get player's formatted balance for display
     * @param player Player
     * @param type Currency type
     * @return Formatted balance string
     */
    public String getFormattedBalance(Player player, DZEconomyAPI.CurrencyType type) {
        double balance = economyAPI.getBalance(player.getUniqueId(), type);
        return economyAPI.formatCurrency(balance, type);
    }

    /**
     * Get all formatted balances for player
     * @param player Player
     * @return Map of currency type to formatted string
     */
    public Map<DZEconomyAPI.CurrencyType, String> getAllFormattedBalances(Player player) {
        Map<DZEconomyAPI.CurrencyType, String> balances = new HashMap<>();

        for (DZEconomyAPI.CurrencyType type : DZEconomyAPI.CurrencyType.values()) {
            balances.put(type, getFormattedBalance(player, type));
        }

        return balances;
    }

    /**
     * Attempt transaction with detailed error reporting
     * @param player Player
     * @param cost Cost to charge
     * @return TransactionResult with success status and error details
     */
    public TransactionResult attemptTransaction(Player player, Cost cost) {
        // Check if player can afford
        if (!canAfford(player, cost)) {
            List<String> missing = getMissingAmounts(player, cost);
            return new TransactionResult(false, "Insufficient funds", missing);
        }

        // Attempt to charge
        boolean success = chargeCost(player, cost);

        if (success) {
            return new TransactionResult(true, "Transaction successful", null);
        } else {
            return new TransactionResult(false, "Transaction failed", null);
        }
    }

    /**
     * Check economy API availability
     * @return true if DZEconomy is available
     */
    public boolean isAvailable() {
        return economyAPI != null;
    }

    /**
     * Get DZEconomy API instance
     * @return DZEconomyAPI instance
     */
    public DZEconomyAPI getAPI() {
        return economyAPI;
    }

    /**
     * Transaction result wrapper
     */
    public static class TransactionResult {
        private final boolean success;
        private final String message;
        private final List<String> details;

        public TransactionResult(boolean success, String message, List<String> details) {
            this.success = success;
            this.message = message;
            this.details = details;
        }

        public boolean isSuccess() {
            return success;
        }

        public String getMessage() {
            return message;
        }

        public List<String> getDetails() {
            return details;
        }

        public boolean hasDetails() {
            return details != null && !details.isEmpty();
        }
    }
}
